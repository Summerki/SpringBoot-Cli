package com.aliatry.springuploadfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringUploadFileApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringUploadFileApplication.class, args);
    }

}
